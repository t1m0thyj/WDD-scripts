$MyPSModulePath = $env:PSModulePath.Split(';')[0]
If ( ! (Test-Path $MyPSModulePath)) {mkdir $MyPSModulePath}
Expand-Archive -Path "C:\Users\yazan\AppData\Local\WinDynamicDesktop\scripts\globalScripts\SaveRestoreExplorerWindow (ReadMe-Plus-Zip )\SaveRestoreExplorerWindow.zip" -DestinationPath $MyPSModulePath